export type NotionPage = {
  id?: string;
}
